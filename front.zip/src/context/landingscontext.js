import React from "react";
const landingsContext = React.createContext();
export { landingsContext };