import React from "react";
const neasContext = React.createContext();
export { neasContext };