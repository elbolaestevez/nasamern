import React, { useEffect, useState,useContext } from "react";
import axios from "axios";
import { neasContext } from "../../../context/neascontext";
import CardNeas from "./CardNeas/CardNeas";

const Neas = () => {
  const [dataneas, setSearch] = useState(null);
  const {neas, save}=useContext(neasContext)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const resp = await axios.get(
          `http://localhost:5000/api/astronomy/neas/dates?1900`
        );
        const data = await resp.data;
        const dataSliced = data.slice(0,10);
        console.log("meteorito",dataSliced);
        save([
          ...neas,
          dataSliced])
        setSearch(dataSliced);
        
      } catch (error) {
        console.log(error);
      }
    };

    fetchData();
    console.log(dataneas);
  }, []);

if(dataneas){
  return (<div className="list">

    
  <>
    {dataneas.length !== 0
      ? dataneas.map((nea, i) => <CardNeas key={i} neadata={nea} />)
      : ""}
  </>
</div>


  )

    }
}


export default Neas;
