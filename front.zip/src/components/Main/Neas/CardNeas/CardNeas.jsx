import React from "react";
import { Link } from "react-router-dom";

function CardNeas({ neadata: nea }) {
  //otra forma es poner props entre parentesis en cards y luego poner copiar ruta del name
  //props.poke[0].name
  return (
    <div className="pokemon-card">
      
      <div className="card-body">
        <Link to={`/nea/${nea.designation}`}>
          Nombre: <p>{nea.designation}</p>
        </Link>
       
        Datos:
        <p>{nea.discovery_date}</p>
        <p>{nea.orbit_class}</p>
        
      </div>
    </div>
  );
}

export default CardNeas;
