export { default } from "./Details";
