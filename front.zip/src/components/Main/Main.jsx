import React, { Component } from "react";
import Landings from "./Landings";
import Neas from "./Neas/Neas";
import Details from "./Details/Details";
import Listado from "./Listado/Listado";
import DetailLanding from "./Listado/CardLanding/DetailLanding/DetailLanding"

import { Route, Routes } from "react-router-dom";
import NewLanding from "./NewLanding/NewLanding";
import Home from "./Home";

class Main extends Component {
  render() {
    return (
      <div>
        <Routes>
          <Route element={<Home/>} path="/"/>
          <Route element={<Landings />} path="/landings" />
          <Route element={<NewLanding />} path="/new" />
          <Route element={<Listado />} path="/listado" />
          <Route element={<Neas />} path="/neas" />
          <Route element={<Details />} path="/nea/:designation" />
          <Route element={<DetailLanding />} path="/landing/:id" />

        </Routes>
        {/* <Neas /> */}
      </div>
    );
  }
}

export default Main;
