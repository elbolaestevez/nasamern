export { default } from "./NewLanding";
