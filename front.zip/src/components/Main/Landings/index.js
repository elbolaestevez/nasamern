export { default } from "./Landings";
