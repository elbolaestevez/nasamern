export { default } from "./DetailLanding";
