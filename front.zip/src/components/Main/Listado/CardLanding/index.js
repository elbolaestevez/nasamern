export { default } from "./CardLanding";
