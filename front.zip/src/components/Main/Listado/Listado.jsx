import React, { useContext, useState } from "react";

import Pagination from '@mui/material/Pagination'
import CardLanding from "./CardLanding/CardLanding"
import { landingsContext } from "../../../context/landingscontext";
import usePagination from "../../../hooks/paginate";


function Listado() {
  const { landings, set } = useContext(landingsContext);
  let [page, setPage] = useState(1);
  const PER_PAGE = 24;

  const count = Math.ceil(landings.length / PER_PAGE);
  const _DATA = usePagination(landings, PER_PAGE);

  const handleChange = (e, p) => {
    setPage(p);
    _DATA.jump(p);
  };
  const removeLanding = (i) =>{
    const remainingLandings = landings.filter((landing,j)=>i!==j)
    set(remainingLandings);
  }
  

  console.log(landings);
  return (
    <div className="list">
       <Pagination
        count={count}
        size="large"
        page={page}
        variant="outlined"
        shape="rounded"
        onChange={handleChange}
      />
      <>
        {landings.length !== 0
          ? _DATA.currentData().map((landing, i) => <CardLanding key={i} objlanding={landing} remove={()=>removeLanding(i)}/>)
          : ""}
      </>
    </div>
  );
}

export default Listado;
